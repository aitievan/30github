document.addEventListener('DOMContentLoaded', () => {
  const links = document.querySelectorAll('#mainNav .nav-link');
  const sections = document.querySelectorAll('section');

  links.forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const target = e.target.getAttribute('data-section');

      // Hide all sections
      sections.forEach(section => section.classList.remove('active'));

      // Show the clicked section
      const targetSection = document.getElementById(target);
      if (targetSection) {
        targetSection.classList.add('active');
        targetSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  const API_KEY = '_QT7bKHtw7xX4HAmyqyH2L8uwntRI6';
const API_URL = 'https://data-api.oxilor.com/rest'; // URL вашего API

document.getElementById('find-cities-btn').addEventListener('click', async () => {
    const cityInput = document.getElementById('city-input').value.trim();
    const resultDiv = document.getElementById('result');
    const cityList = document.getElementById('cityList');

    if (!cityInput) {
        resultDiv.style.display = 'block';
        resultDiv.textContent = 'Шаарды киргизиңиз!';
        resultDiv.className = 'alert alert-danger';
        return;
    }

    resultDiv.style.display = 'block';
    resultDiv.textContent = 'Маалымат жүктөлүүдө...';
    resultDiv.className = 'alert alert-info';

    try {
        const response = await fetch(`${API_URL}/search-regions?searchTerm=${encodeURIComponent(cityInput)}`, {
            headers: { 'Authorization': `Bearer ${API_KEY}` }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        renderCityInfo(data);
    } catch (error) {
        resultDiv.textContent = 'Ката: ' + error.message;
        resultDiv.className = 'alert alert-danger';
    }
});

function renderCityInfo(data) {
    const resultDiv = document.getElementById('result');
    const cityList = document.getElementById('cityList');
    
    cityList.innerHTML = ''; // Очистить старые данные

    if (!data || data.length === 0) {
        resultDiv.textContent = 'Кошуна шаарлар табылган жок.';
        resultDiv.className = 'alert alert-warning';
        return;
    }

    data.forEach(city => {
        const { name, latitude, longitude, population } = city;
        const coordinates = `${latitude || 'N/A'}, ${longitude || 'N/A'}`;
        const populationText = population || 'N/A';
        
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${name || 'N/A'}</td>
            <td>${coordinates}</td>
            <td>${populationText}</td>
        `;
        cityList.appendChild(tr);
    });

    resultDiv.style.display = 'none'; // Скрыть "loading" сообщение
}

});

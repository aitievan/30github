import React from 'react';
import './App.css'
import CourseApp from './component/CourseApp';

function App() {
  return (
    <div className="App">
      <CourseApp />
    </div>
  );
}

export default App;

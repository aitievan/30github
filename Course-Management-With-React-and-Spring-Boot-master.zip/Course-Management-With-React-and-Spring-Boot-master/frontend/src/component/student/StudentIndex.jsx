import React, { Component } from 'react'

class StudentIndex extends Component {
    constructor(props) {
        super(props)

        this.state = {

        }
    }

    render() {
        return (
            <div>
                Student Index Page
            </div>
        )
    }
}

export default StudentIndex
